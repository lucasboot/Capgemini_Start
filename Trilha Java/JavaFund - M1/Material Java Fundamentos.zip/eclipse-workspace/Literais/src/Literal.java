
public class Literal {

	public static void main(String[] args) {
		int numero;
		String cadeiaCaracteres;
		char caracter;
		boolean certoOuErrado;
		
		numero = 20;
		cadeiaCaracteres = "** Meu Curso de Java Fundamentos";
		caracter = 'N';
		certoOuErrado = false;
		
		System.out.println(" O valor de n�mero � : " + numero);
		System.out.println(" O valor de cadeiaCaracteres � : " + cadeiaCaracteres);
		System.out.println(" O valor de caracter � : " + caracter);
		System.out.println(" O valor de certoOuErrado � : " + certoOuErrado);

	}

}
