
public class TipoDado {

	public static void main(String[] args) {
		
		// demonstra��o de alguns tipos de dados
		int     numero;
		float   decimalCurto;
		double  decimalLongo;
		char    caracter;
		String  cadeiaCaracteres;
		
		numero       = 10;
		decimalCurto = 10.5f;
		decimalLongo = 20.5;
		caracter     = 'A';
		cadeiaCaracteres = "** Meu Curso de Java Fundamentos em 2021 **";
	}

}
