
public class Pessoa {

		public String nome;
		public String situacaoPessoa;

		@Override
		public String toString() {
			return "Pessoa [nome=" + nome + ", situacaoPessoa=" + situacaoPessoa + "]";
		}

		
	
		
}
