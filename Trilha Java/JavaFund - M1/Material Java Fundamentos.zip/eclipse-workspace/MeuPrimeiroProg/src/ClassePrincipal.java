
public class ClassePrincipal {

	public static void main(String[] args) {
		final float numero  = 855.6f;
		System.out.println("Valor de n�mero � :" + numero);
	}

}
