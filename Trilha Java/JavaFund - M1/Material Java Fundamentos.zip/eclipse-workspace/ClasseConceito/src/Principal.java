
public class Principal {

	public static void main(String[] args) {
		// Encapsulamento

		Pessoa pes = new Pessoa();
		pes.setNomePessoa("JO�O DO NASCIMENTO");
		pes.setIdadePessoa(15);
		System.out.println(pes.toString());
	}
}
