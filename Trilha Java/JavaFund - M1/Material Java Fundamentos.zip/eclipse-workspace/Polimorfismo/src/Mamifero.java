
abstract class Mamifero {

	public abstract double cotaDiariaLeite();
}
