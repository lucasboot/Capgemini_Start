
public class Rato extends Mamifero{

		public double cotaDiariaLeite() {
			return 0.5;
		}
}
