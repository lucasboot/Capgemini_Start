
public class Elefante extends Mamifero {
	
	public double cotaDiariaLeite() {
		return 30.0;
	}

}
